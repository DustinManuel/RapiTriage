import 'package:flutter/material.dart';
import 'dart:math';
import 'dart:async';

void main() {
  runApp(TriageApp());
}

class TriageApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Real-time Triage Monitoring',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: TriageDashboard(),
    );
  }
}

class TriageDashboard extends StatefulWidget {
  @override
  _TriageDashboardState createState() => _TriageDashboardState();
}

class _TriageDashboardState extends State<TriageDashboard> {
  List<Pasien> _pasienList = [];
  Timer? _monitoringTimer;
  final Random _random = Random();
  final List<Color> _priorityColors = [
    Colors.green,
    Colors.orange,
    Colors.red
  ];

  @override
  void initState() {
    super.initState();
    _startMonitoring();
    // Tambahkan beberapa pasien contoh
    _addSamplePatients();
  }

  void _addSamplePatients() {
    final patients = [
      Pasien(
        nama: "Budi Santoso",
        usia: 35,
        kelamin: "Laki-laki",
        suhu: 36.5,
        denyutNadi: 72,
        lajuPernapasan: 16,
        tekananDarah: "120/80",
        keluhanUtama: "Pusing ringan"
      ),
      Pasien(
        nama: "Ani Wijaya",
        usia: 45,
        kelamin: "Perempuan",
        suhu: 38.2,
        denyutNadi: 98,
        lajuPernapasan: 22,
        tekananDarah: "135/85",
        keluhanUtama: "Demam tinggi"
      ),
      Pasien(
        nama: "Rudi Hermawan",
        usia: 50,
        kelamin: "Laki-laki",
        suhu: 37.8,
        denyutNadi: 115,
        lajuPernapasan: 28,
        tekananDarah: "150/95",
        keluhanUtama: "Nyeri dada"
      ),
    ];

    setState(() {
      _pasienList.addAll(patients);
      _pasienList.forEach((p) => p.hitungTriage());
      _pasienList.sort((a, b) => b.prioritas.compareTo(a.prioritas));
    });
  }

  @override
  void dispose() {
    _monitoringTimer?.cancel();
    super.dispose();
  }

  void _startMonitoring() {
    _monitoringTimer = Timer.periodic(Duration(seconds: 5), (timer) {
      setState(() {
        // Simulasi perubahan parameter vital secara acak
        for (var pasien in _pasienList) {
          // Perubahan denyut nadi (-10 sampai +10)
          pasien.denyutNadi = (pasien.denyutNadi + _random.nextInt(21) - 10).clamp(40, 180);
          
          // Perubahan laju pernapasan (-5 sampai +5)
          pasien.lajuPernapasan = (pasien.lajuPernapasan + _random.nextInt(11) - 5).clamp(8, 40);
          
          // Perubahan tekanan darah
          final perubahanSistolik = _random.nextInt(21) - 10; // -10 sampai +10
          final perubahanDiastolik = _random.nextInt(15) - 7; // -7 sampai +7
          
          final parts = pasien.tekananDarah.split('/');
          if (parts.length == 2) {
            try {
              int sistolik = (int.parse(parts[0]) + perubahanSistolik).clamp(70, 220);
              int diastolik = (int.parse(parts[1]) + perubahanDiastolik).clamp(40, 130);
              pasien.tekananDarah = '$sistolik/$diastolik';
            } catch (e) {
              pasien.tekananDarah = '120/80';
            }
          }
          
          // Perubahan suhu (-0.5 sampai +0.5)
          pasien.suhu = (pasien.suhu + (_random.nextDouble() - 0.5)).clamp(35.0, 41.0);
          
          // Hitung ulang prioritas
          pasien.hitungTriage();
        }
        
        // Urutkan berdasarkan prioritas (tinggi ke rendah)
        _pasienList.sort((a, b) => b.prioritas.compareTo(a.prioritas));
      });
    });
  }

  void _tambahPasien(Pasien pasien) {
    setState(() {
      _pasienList.add(pasien);
      _pasienList.sort((a, b) => b.prioritas.compareTo(a.prioritas));
    });
  }

  void _hapusPasien(String id) {
    setState(() {
      _pasienList.removeWhere((p) => p.id == id);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Real-time Triage Monitoring'),
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => TriageForm(onSubmit: _tambahPasien),
                ),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          _buildPriorityLegend(),
          Expanded(
            child: ListView.builder(
              itemCount: _pasienList.length,
              itemBuilder: (context, index) {
                final pasien = _pasienList[index];
                return _buildPasienCard(pasien);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPriorityLegend() {
    return Container(
      padding: EdgeInsets.all(8),
      color: Colors.grey[200],
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildLegendItem(Colors.red, 'Prioritas Tinggi'),
          _buildLegendItem(Colors.orange, 'Prioritas Sedang'),
          _buildLegendItem(Colors.green, 'Prioritas Rendah'),
        ],
      ),
    );
  }

  Widget _buildLegendItem(Color color, String text) {
    return Row(
      children: [
        Container(
          width: 16,
          height: 16,
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
          ),
        ),
        SizedBox(width: 8),
        Text(text),
      ],
    );
  }

  Widget _buildPasienCard(Pasien pasien) {
    final priorityColor = _priorityColors[pasien.prioritas.clamp(0, 2)];
    
    return Card(
      margin: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      elevation: 2,
      shape: RoundedRectangleBorder(
        side: BorderSide(color: priorityColor.withOpacity(0.5), width: 2),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  pasien.nama,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                    color: priorityColor,
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.delete, color: Colors.grey),
                  onPressed: () => _hapusPasien(pasien.id),
                ),
              ],
            ),
            SizedBox(height: 8),
            Row(
              children: [
                Text('${pasien.usia} tahun', style: TextStyle(fontSize: 14)),
                SizedBox(width: 16),
                Text(pasien.kelamin, style: TextStyle(fontSize: 14)),
              ],
            ),
            SizedBox(height: 16),
            _buildVitalSignsRow(pasien),
            SizedBox(height: 16),
            Text(
              'Keluhan: ${pasien.keluhanUtama}',
              style: TextStyle(fontStyle: FontStyle.italic),
            ),
            SizedBox(height: 8),
            Container(
              padding: EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: priorityColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Row(
                children: [
                  Icon(
                    Icons.warning,
                    color: priorityColor,
                    size: 20,
                  ),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      pasien.rekomendasi,
                      style: TextStyle(
                        color: priorityColor,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildVitalSignsRow(Pasien pasien) {
    return Table(
      columnWidths: {
        0: FixedColumnWidth(100),
        1: FixedColumnWidth(100),
        2: FixedColumnWidth(100),
      },
      children: [
        TableRow(
          children: [
            _buildVitalSignItem('Suhu', '${pasien.suhu.toStringAsFixed(1)}°C'),
            _buildVitalSignItem('Nadi', '${pasien.denyutNadi}/menit'),
            _buildVitalSignItem('Pernapasan', '${pasien.lajuPernapasan}/menit'),
          ],
        ),
        TableRow(
          children: [
            _buildVitalSignItem('TD', pasien.tekananDarah),
            _buildVitalSignItem('Prioritas', _getPriorityText(pasien.prioritas)),
            Container(), // Empty cell for alignment
          ],
        ),
      ],
    );
  }

  Widget _buildVitalSignItem(String label, String value) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              color: Colors.grey[600],
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  String _getPriorityText(int priority) {
    switch (priority) {
      case 2: return 'Tinggi';
      case 1: return 'Sedang';
      default: return 'Rendah';
    }
  }
}

class TriageForm extends StatefulWidget {
  final Function(Pasien) onSubmit;

  TriageForm({required this.onSubmit});

  @override
  _TriageFormState createState() => _TriageFormState();
}

class _TriageFormState extends State<TriageForm> {
  final _formKey = GlobalKey<FormState>();
  final _namaController = TextEditingController();
  final _usiaController = TextEditingController();
  final _suhuController = TextEditingController(text: '36.5');
  final _denyutNadiController = TextEditingController(text: '80');
  final _lajuPernapasanController = TextEditingController(text: '16');
  final _tekananDarahController = TextEditingController(text: '120/80');
  final _keluhanController = TextEditingController();

  String _kelamin = 'Laki-laki';
  List<String> _optionsKelamin = ['Laki-laki', 'Perempuan'];

  @override
  void dispose() {
    _namaController.dispose();
    _usiaController.dispose();
    _suhuController.dispose();
    _denyutNadiController.dispose();
    _lajuPernapasanController.dispose();
    _tekananDarahController.dispose();
    _keluhanController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tambah Pasien Baru'),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _namaController,
                decoration: InputDecoration(
                  labelText: 'Nama Pasien',
                  border: OutlineInputBorder(),
                ),
                validator: (value) =>
                    value!.isEmpty ? 'Masukkan nama pasien' : null,
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _usiaController,
                decoration: InputDecoration(
                  labelText: 'Usia',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
                validator: (value) =>
                    value!.isEmpty ? 'Masukkan usia' : null,
              ),
              SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: _kelamin,
                decoration: InputDecoration(
                  labelText: 'Jenis Kelamin',
                  border: OutlineInputBorder(),
                ),
                items: _optionsKelamin
                    .map((value) => DropdownMenuItem(
                          value: value,
                          child: Text(value),
                        ))
                    .toList(),
                onChanged: (value) => setState(() => _kelamin = value!),
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _suhuController,
                decoration: InputDecoration(
                  labelText: 'Suhu Tubuh (°C)',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.numberWithOptions(decimal: true),
                validator: (value) =>
                    value!.isEmpty ? 'Masukkan suhu tubuh' : null,
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _denyutNadiController,
                decoration: InputDecoration(
                  labelText: 'Denyut Nadi (/menit)',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
                validator: (value) =>
                    value!.isEmpty ? 'Masukkan denyut nadi' : null,
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _lajuPernapasanController,
                decoration: InputDecoration(
                  labelText: 'Laju Pernapasan (/menit)',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
                validator: (value) =>
                    value!.isEmpty ? 'Masukkan laju pernapasan' : null,
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _tekananDarahController,
                decoration: InputDecoration(
                  labelText: 'Tekanan Darah (mmHg)',
                  border: OutlineInputBorder(),
                  hintText: 'Contoh: 120/80',
                ),
                validator: (value) =>
                    !RegExp(r'^\d{2,3}/\d{2,3}$').hasMatch(value!)
                        ? 'Format: 120/80'
                        : null,
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _keluhanController,
                decoration: InputDecoration(
                  labelText: 'Keluhan Utama',
                  border: OutlineInputBorder(),
                ),
                maxLines: 3,
                validator: (value) =>
                    value!.isEmpty ? 'Masukkan keluhan utama' : null,
              ),
              SizedBox(height: 24),
              ElevatedButton(
                onPressed: _submitForm,
                child: Text('Simpan Pasien', style: TextStyle(fontSize: 18)),
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(vertical: 16),
                  minimumSize: Size(double.infinity, 0),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      final pasien = Pasien(
        nama: _namaController.text,
        usia: int.parse(_usiaController.text),
        kelamin: _kelamin,
        suhu: double.parse(_suhuController.text),
        denyutNadi: int.parse(_denyutNadiController.text),
        lajuPernapasan: int.parse(_lajuPernapasanController.text),
        tekananDarah: _tekananDarahController.text,
        keluhanUtama: _keluhanController.text,
      );

      pasien.hitungTriage();
      widget.onSubmit(pasien);
      Navigator.pop(context);
    }
  }
}

class Pasien {
  final String id = DateTime.now().millisecondsSinceEpoch.toString();
  final String nama;
  final int usia;
  final String kelamin;
  double suhu;
  int denyutNadi;
  int lajuPernapasan;
  String tekananDarah;
  final String keluhanUtama;
  String rekomendasi = '';
  int prioritas = 0; // 0: rendah, 1: sedang, 2: tinggi

  final List<String> _keluhanPrioritasTinggi = [
    'nyeri dada',
    'sesak napas',
    'pendarahan hebat',
    'pingsan',
    'kejang',
    'luka bakar parah',
    'trauma kepala',
    'stroke',
    'serangan jantung'
  ];

  final List<String> _keluhanPrioritasSedang = [
    'demam tinggi',
    'muntah terus menerus',
    'diare parah',
    'nyeri perut hebat',
    'pusing berat',
    'luka sedang'
  ];

  Pasien({
    required this.nama,
    required this.usia,
    required this.kelamin,
    required this.suhu,
    required this.denyutNadi,
    required this.lajuPernapasan,
    required this.tekananDarah,
    required this.keluhanUtama,
  });

  void hitungTriage() {
    int prioritas = 0;
    int vitalScore = 0;

    // Parse tekanan darah
    int sistolik = 120;
    int diastolik = 80;
    try {
      final parts = tekananDarah.split('/');
      if (parts.length == 2) {
        sistolik = int.parse(parts[0]);
        diastolik = int.parse(parts[1]);
      }
    } catch (e) {
      sistolik = 120;
      diastolik = 80;
    }

    // Evaluasi suhu
    if (suhu >= 39.0) vitalScore += 2;
    else if (suhu >= 38.0 || suhu <= 35.0) vitalScore += 1;

    // Evaluasi denyut nadi
    if (denyutNadi >= 120 || denyutNadi <= 50) vitalScore += 2;
    else if (denyutNadi >= 100 || denyutNadi <= 60) vitalScore += 1;

    // Evaluasi laju pernapasan
    if (lajuPernapasan >= 30 || lajuPernapasan <= 10) vitalScore += 2;
    else if (lajuPernapasan >= 20 || lajuPernapasan <= 12) vitalScore += 1;

    // Evaluasi tekanan darah
    if (sistolik >= 180 || sistolik <= 90 || diastolik >= 120) vitalScore += 2;
    else if (sistolik >= 160 || sistolik <= 100 || diastolik >= 100) vitalScore += 1;

    // Tentukan prioritas berdasarkan skor vital
    if (vitalScore >= 3) prioritas = 2;
    else if (vitalScore >= 1) prioritas = 1;

    // Evaluasi berdasarkan keluhan utama
    final keluhanLower = keluhanUtama.toLowerCase();

    for (var keluhan in _keluhanPrioritasTinggi) {
      if (keluhanLower.contains(keluhan.toLowerCase())) {
        prioritas = max(prioritas, 2);
        break;
      }
    }

    if (prioritas < 2) {
      for (var keluhan in _keluhanPrioritasSedang) {
        if (keluhanLower.contains(keluhan.toLowerCase())) {
          prioritas = max(prioritas, 1);
          break;
        }
      }
    }

    // Tentukan rekomendasi
    switch (prioritas) {
      case 2:
        rekomendasi = 'PRIORITAS TINGGI - Segera ke IGD';
        break;
      case 1:
        rekomendasi = 'PRIORITAS MENENGAH - Perlu evaluasi dokter dalam 1 jam';
        break;
      default:
        rekomendasi = 'PRIORITAS RENDAH - Dapat menunggu evaluasi';
    }

    this.prioritas = prioritas;
  }
}